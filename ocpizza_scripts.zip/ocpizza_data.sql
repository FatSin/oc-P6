USE ocpizza;


INSERT INTO restaurant 
	(id_rest,adresse,nom,numtel)
VALUES
	(1,"3 rue de la Paix","Paris Centre01","0101055304"),
	(2,"15 avenue de la Republique","Paris Est01","0198229002")
;

INSERT INTO aliment 
	(id_aliment,nom)
VALUES
	(1,"sauce tomate"),
	(2,"pate"),
	(3,"mozzarella"),
	(4,"jambon"),
	(5,"aubergine")
;

INSERT INTO pizza 
	(id_pizza,nom,prix)
VALUES
	(1,"reine",8.90),
	(2,"oc_speciale",12.50),
	(3,"margharita",10.90)
;

INSERT INTO catalogue 
	(id,id_rest,id_pizza)
VALUES
	(1,1,1),
	(2,1,2),
	(3,1,3),
	(4,2,1),
	(5,2,2)
;


INSERT INTO stock 
	(id_rest,id_aliment,statut,quantite_restante)
VALUES
	(1,1,"ok",5),
	(1,2,"ok",3),
	(1,3,"ok",4),
	(1,4,"ok",3),
	(1,5,"ok",2),
	(2,1,"ok",2),
	(2,2,"ko",0),
	(2,3,"ok",3),
	(2,4,"ok",3),
	(2,5,"ko",0)
;

INSERT INTO recette 
	(id_pizza,id_aliment,version,portion)
VALUES
	(1,1,1,1),
	(1,2,1,1),
	(1,3,1,1),
	(1,4,1,1),
	(2,1,1,1),
	(2,2,1,1),
	(2,3,1,2),
	(2,4,1,0),
	(2,5,1,2),
	(3,1,1,1),
	(3,2,1,1),
	(3,3,1,2),
	(3,4,1,0),
	(3,5,1,0)
;

INSERT INTO promotion 
	(id,nom,date_debut,pourcentage,date_fin,id_rest,id_pizza)
VALUES
	(1,"hiver2018",'2017-12-01',5,'2018-02-01',1,2)
;


INSERT INTO client 
	(id_client,email,num_tel,nom,prenom,mot_de_passe)
VALUES
	(1,"cjane@google.com","0601020304","Calamity","Jane",SHA2('pass123',256)),
	(2,"gijoe@google.com","0601030402","Joe","GI",SHA2('passabc',256)),
	(3,"glagaffe@google.com","0620930402","Lagaffe","Gaston",SHA2('monpass',256)),
	(4,"asane@homail.com","0605530402","Sane","Aladdin",SHA2('abcpass',256)),
	(5,"ejolie@hotmail.com","0624330402","Jolie","Emilie",SHA2('0123abc',256))
;

INSERT INTO employe 
	(id_client,statut,id_rest)
VALUES
	(2,"disponible",1),
	(3,"disponible",2),
	(4,"occupe",2),
	(5,"occupe",1)
;

INSERT INTO preparateur 
	(id_client)
VALUES
	(2),
	(4)

;

INSERT INTO livreur 
	(id_client)
VALUES
	(3),
	(5)
;

INSERT INTO commande 
	(id_commande,statut,mode_commande,date_creation,date_fermeture,id_client,id_rest)
VALUES
	(1,"terminée","internet",'2017-01-05 13:21:00','2017-01-05 13:55:00',1,1),
	(2,"en cours de preparation","direct",'2017-01-10 11:21:00',NULL,2,1),
	(3,"en cours de livraison","téléphone",'2017-01-10 20:03:00',NULL,4,2)
;

INSERT INTO livraison 
	(id,id_commande,date_debut,date_fin,adresse,statut,nom_client,prenom_client,num_client)
VALUES
	(1,1,'2017-01-05 13:40:00','2017-01-05 13:55:00',"3 rue du coulommiers","terminée",NULL,NULL,NULL),
	(2,3,'2017-01-10 20:15:00',NULL,"4 allée des maroilles","en cours","Payet","Emmanuelle","0673920237")
;
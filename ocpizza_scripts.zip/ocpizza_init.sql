CREATE DATABASE ocpizza;
USE ocpizza;
SET NAMES utf8;
SET CHARACTER SET utf8;
SET character_set_connection=utf8;


CREATE TABLE aliment (
                id_aliment INT AUTO_INCREMENT NOT NULL,
                nom VARCHAR(40) NOT NULL,
                PRIMARY KEY (id_aliment)
);


CREATE TABLE pizza (
                id_pizza INT AUTO_INCREMENT NOT NULL,
                nom VARCHAR(40) NOT NULL,
                prix DECIMAL NOT NULL,
                PRIMARY KEY (id_pizza)
);


CREATE TABLE recette (
                id_pizza INT NOT NULL,
                id_aliment INT NOT NULL,
                version INT NOT NULL,
                portion INT NOT NULL,
                PRIMARY KEY (id_pizza, id_aliment, version)
);


CREATE TABLE restaurant (
                id_rest INT AUTO_INCREMENT NOT NULL,
                adresse VARCHAR(40) NOT NULL,
                nom VARCHAR(40) NOT NULL,
                numTel CHAR(10) NOT NULL,
                PRIMARY KEY (id_rest)
);


CREATE TABLE promotion (
                id INT AUTO_INCREMENT NOT NULL,
                nom VARCHAR(40) NOT NULL,
                date_debut DATE NOT NULL,
                pourcentage INT NOT NULL,
                date_fin DATE NOT NULL,
                id_rest INT NOT NULL,
                id_pizza INT NOT NULL,
                PRIMARY KEY (id)
);


CREATE TABLE catalogue (
                id INT NOT NULL,
                id_rest INT NOT NULL,
                id_pizza INT NOT NULL,
                PRIMARY KEY (id, id_rest, id_pizza)
);


CREATE TABLE stock (
                id_rest INT NOT NULL,
                id_aliment INT NOT NULL,
                statut VARCHAR(40) NOT NULL,
                quantite_restante INT,
                PRIMARY KEY (id_rest, id_aliment)
);


CREATE TABLE client (
                id_client INT AUTO_INCREMENT NOT NULL,
                email VARCHAR(40) NOT NULL,
                num_tel CHAR(10) NOT NULL,
                nom VARCHAR(40) NOT NULL,
                prenom VARCHAR(40) NOT NULL,
                mot_de_passe CHAR(64) NOT NULL,
                points_fidelite INT,
                PRIMARY KEY (id_client)
);


CREATE TABLE commande (
                id_commande INT AUTO_INCREMENT NOT NULL,
                statut VARCHAR(40) NOT NULL,
                mode_commande VARCHAR(40) NOT NULL,
                date_creation DATETIME NOT NULL,
                date_fermeture DATETIME,
                id_client INT NOT NULL,
                id_rest INT NOT NULL,
                PRIMARY KEY (id_commande)
);


CREATE TABLE employe (
                id_client INT NOT NULL,
                statut VARCHAR(40) NOT NULL,
                id_rest INT NOT NULL,
                PRIMARY KEY (id_client)
);


CREATE TABLE livreur (
                id_client INT NOT NULL,
                PRIMARY KEY (id_client)
);


CREATE TABLE livraison (
                id INT AUTO_INCREMENT NOT NULL,
                id_commande INT NOT NULL,
                date_debut DATETIME NOT NULL,
                date_fin DATETIME,
                adresse VARCHAR(40) NOT NULL,
                statut VARCHAR(40) NOT NULL,
				nom_client VARCHAR(40),
				prenom_client VARCHAR(40),
				num_client VARCHAR(40),
                PRIMARY KEY (id, id_commande)
);


CREATE TABLE preparateur (
                id_client INT NOT NULL,
                PRIMARY KEY (id_client)
);


ALTER TABLE stock ADD CONSTRAINT aliment_stock_fk
FOREIGN KEY (id_aliment)
REFERENCES aliment (id_aliment)
ON DELETE RESTRICT
ON UPDATE CASCADE;

ALTER TABLE recette ADD CONSTRAINT aliment_recette_fk
FOREIGN KEY (id_aliment)
REFERENCES aliment (id_aliment)
ON DELETE RESTRICT
ON UPDATE CASCADE;

ALTER TABLE catalogue ADD CONSTRAINT pizza_catalogue_fk
FOREIGN KEY (id_pizza)
REFERENCES pizza (id_pizza)
ON DELETE RESTRICT
ON UPDATE CASCADE;

ALTER TABLE recette ADD CONSTRAINT pizza_recette_fk
FOREIGN KEY (id_pizza)
REFERENCES pizza (id_pizza)
ON DELETE RESTRICT
ON UPDATE CASCADE;

ALTER TABLE promotion ADD CONSTRAINT pizza_promotion_fk
FOREIGN KEY (id_pizza)
REFERENCES pizza (id_pizza)
ON DELETE RESTRICT
ON UPDATE CASCADE;

ALTER TABLE commande ADD CONSTRAINT restaurant_commande_fk
FOREIGN KEY (id_rest)
REFERENCES restaurant (id_rest)
ON DELETE RESTRICT
ON UPDATE CASCADE;

ALTER TABLE employe ADD CONSTRAINT restaurant_employe_fk
FOREIGN KEY (id_rest)
REFERENCES restaurant (id_rest)
ON DELETE RESTRICT
ON UPDATE CASCADE;

ALTER TABLE stock ADD CONSTRAINT restaurant_stock_fk
FOREIGN KEY (id_rest)
REFERENCES restaurant (id_rest)
ON DELETE RESTRICT
ON UPDATE CASCADE;

ALTER TABLE catalogue ADD CONSTRAINT restaurant_catalogue_fk
FOREIGN KEY (id_rest)
REFERENCES restaurant (id_rest)
ON DELETE RESTRICT
ON UPDATE CASCADE;

ALTER TABLE promotion ADD CONSTRAINT restaurant_promotion_fk
FOREIGN KEY (id_rest)
REFERENCES restaurant (id_rest)
ON DELETE RESTRICT
ON UPDATE CASCADE;

ALTER TABLE employe ADD CONSTRAINT client_employe_fk
FOREIGN KEY (id_client)
REFERENCES client (id_client)
ON DELETE RESTRICT
ON UPDATE CASCADE;

ALTER TABLE commande ADD CONSTRAINT client_commande_fk
FOREIGN KEY (id_client)
REFERENCES client (id_client)
ON DELETE RESTRICT
ON UPDATE CASCADE;

ALTER TABLE livraison ADD CONSTRAINT commande_livraison_fk
FOREIGN KEY (id_commande)
REFERENCES commande (id_commande)
ON DELETE RESTRICT
ON UPDATE CASCADE;

ALTER TABLE preparateur ADD CONSTRAINT employe_preparateur_fk
FOREIGN KEY (id_client)
REFERENCES employe (id_client)
ON DELETE RESTRICT
ON UPDATE CASCADE;

ALTER TABLE livreur ADD CONSTRAINT employe_livreur_fk
FOREIGN KEY (id_client)
REFERENCES employe (id_client)
ON DELETE RESTRICT
ON UPDATE CASCADE;

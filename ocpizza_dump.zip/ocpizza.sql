-- MySQL dump 10.13  Distrib 5.7.20, for Win64 (x86_64)
--
-- Host: localhost    Database: ocpizza
-- ------------------------------------------------------
-- Server version	5.7.20-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `aliment`
--

DROP TABLE IF EXISTS `aliment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `aliment` (
  `id_aliment` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(40) NOT NULL,
  PRIMARY KEY (`id_aliment`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aliment`
--

LOCK TABLES `aliment` WRITE;
/*!40000 ALTER TABLE `aliment` DISABLE KEYS */;
INSERT INTO `aliment` VALUES (1,'sauce tomate'),(2,'pate'),(3,'mozzarella'),(4,'jambon'),(5,'aubergine');
/*!40000 ALTER TABLE `aliment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `catalogue`
--

DROP TABLE IF EXISTS `catalogue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `catalogue` (
  `id` int(11) NOT NULL,
  `id_rest` int(11) NOT NULL,
  `id_pizza` int(11) NOT NULL,
  PRIMARY KEY (`id`,`id_rest`,`id_pizza`),
  KEY `pizza_catalogue_fk` (`id_pizza`),
  KEY `restaurant_catalogue_fk` (`id_rest`),
  CONSTRAINT `pizza_catalogue_fk` FOREIGN KEY (`id_pizza`) REFERENCES `pizza` (`id_pizza`) ON UPDATE CASCADE,
  CONSTRAINT `restaurant_catalogue_fk` FOREIGN KEY (`id_rest`) REFERENCES `restaurant` (`id_rest`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `catalogue`
--

LOCK TABLES `catalogue` WRITE;
/*!40000 ALTER TABLE `catalogue` DISABLE KEYS */;
INSERT INTO `catalogue` VALUES (1,1,1),(4,2,1),(2,1,2),(5,2,2),(3,1,3);
/*!40000 ALTER TABLE `catalogue` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `client`
--

DROP TABLE IF EXISTS `client`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `client` (
  `id_client` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(40) NOT NULL,
  `num_tel` char(10) NOT NULL,
  `nom` varchar(40) NOT NULL,
  `prenom` varchar(40) NOT NULL,
  `mot_de_passe` char(64) NOT NULL,
  `points_fidelite` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_client`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `client`
--

LOCK TABLES `client` WRITE;
/*!40000 ALTER TABLE `client` DISABLE KEYS */;
INSERT INTO `client` VALUES (1,'cjane@google.com','0601020304','Calamity','Jane','9b8769a4a742959a2d0298c36fb70623f2dfacda8436237df08d8dfd5b37374c',NULL),(2,'gijoe@google.com','0601030402','Joe','GI','6272a94b52b95b50a5304af63d146fe8c7151e094927437e0cf2919f212888ff',NULL),(3,'glagaffe@google.com','0620930402','Lagaffe','Gaston','a89621d2d0abc12490a55b2c66680c7893cc1e537ffd035e8811c3ad6565734c',NULL),(4,'asane@homail.com','0605530402','Sane','Aladdin','a551515c988cf4d9b97f59fd2686ba4e1b2629f26da9ced9f14b7bff94b27074',NULL),(5,'ejolie@hotmail.com','0624330402','Jolie','Emilie','d22ec3d900a8a525d81d390fe519c894a3890b5578ab2f2a975239f247cad0bf',NULL);
/*!40000 ALTER TABLE `client` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `commande`
--

DROP TABLE IF EXISTS `commande`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `commande` (
  `id_commande` int(11) NOT NULL AUTO_INCREMENT,
  `statut` varchar(40) NOT NULL,
  `mode_commande` varchar(40) NOT NULL,
  `date_creation` datetime NOT NULL,
  `date_fermeture` datetime DEFAULT NULL,
  `id_client` int(11) NOT NULL,
  `id_rest` int(11) NOT NULL,
  PRIMARY KEY (`id_commande`),
  KEY `restaurant_commande_fk` (`id_rest`),
  KEY `client_commande_fk` (`id_client`),
  CONSTRAINT `client_commande_fk` FOREIGN KEY (`id_client`) REFERENCES `client` (`id_client`) ON UPDATE CASCADE,
  CONSTRAINT `restaurant_commande_fk` FOREIGN KEY (`id_rest`) REFERENCES `restaurant` (`id_rest`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `commande`
--

LOCK TABLES `commande` WRITE;
/*!40000 ALTER TABLE `commande` DISABLE KEYS */;
INSERT INTO `commande` VALUES (1,'terminée','internet','2017-01-05 13:21:00','2017-01-05 13:55:00',1,1),(2,'en cours de preparation','direct','2017-01-10 11:21:00',NULL,2,1),(3,'en cours de livraison','téléphone','2017-01-10 20:03:00',NULL,4,2);
/*!40000 ALTER TABLE `commande` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employe`
--

DROP TABLE IF EXISTS `employe`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `employe` (
  `id_client` int(11) NOT NULL,
  `statut` varchar(40) NOT NULL,
  `id_rest` int(11) NOT NULL,
  PRIMARY KEY (`id_client`),
  KEY `restaurant_employe_fk` (`id_rest`),
  CONSTRAINT `client_employe_fk` FOREIGN KEY (`id_client`) REFERENCES `client` (`id_client`) ON UPDATE CASCADE,
  CONSTRAINT `restaurant_employe_fk` FOREIGN KEY (`id_rest`) REFERENCES `restaurant` (`id_rest`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employe`
--

LOCK TABLES `employe` WRITE;
/*!40000 ALTER TABLE `employe` DISABLE KEYS */;
INSERT INTO `employe` VALUES (2,'disponible',1),(3,'disponible',2),(4,'occupe',2),(5,'occupe',1);
/*!40000 ALTER TABLE `employe` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `livraison`
--

DROP TABLE IF EXISTS `livraison`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `livraison` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_commande` int(11) NOT NULL,
  `date_debut` datetime NOT NULL,
  `date_fin` datetime DEFAULT NULL,
  `adresse` varchar(40) NOT NULL,
  `statut` varchar(40) NOT NULL,
  `nom_client` varchar(40) DEFAULT NULL,
  `prenom_client` varchar(40) DEFAULT NULL,
  `num_client` varchar(40) DEFAULT NULL,
  PRIMARY KEY (`id`,`id_commande`),
  KEY `commande_livraison_fk` (`id_commande`),
  CONSTRAINT `commande_livraison_fk` FOREIGN KEY (`id_commande`) REFERENCES `commande` (`id_commande`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `livraison`
--

LOCK TABLES `livraison` WRITE;
/*!40000 ALTER TABLE `livraison` DISABLE KEYS */;
INSERT INTO `livraison` VALUES (1,1,'2017-01-05 13:40:00','2017-01-05 13:55:00','3 rue du coulommiers','terminée',NULL,NULL,NULL),(2,3,'2017-01-10 20:15:00',NULL,'4 allée des maroilles','en cours','Payet','Emmanuelle','0673920237');
/*!40000 ALTER TABLE `livraison` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `livreur`
--

DROP TABLE IF EXISTS `livreur`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `livreur` (
  `id_client` int(11) NOT NULL,
  PRIMARY KEY (`id_client`),
  CONSTRAINT `employe_livreur_fk` FOREIGN KEY (`id_client`) REFERENCES `employe` (`id_client`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `livreur`
--

LOCK TABLES `livreur` WRITE;
/*!40000 ALTER TABLE `livreur` DISABLE KEYS */;
INSERT INTO `livreur` VALUES (3),(5);
/*!40000 ALTER TABLE `livreur` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pizza`
--

DROP TABLE IF EXISTS `pizza`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pizza` (
  `id_pizza` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(40) NOT NULL,
  `prix` decimal(10,0) NOT NULL,
  PRIMARY KEY (`id_pizza`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pizza`
--

LOCK TABLES `pizza` WRITE;
/*!40000 ALTER TABLE `pizza` DISABLE KEYS */;
INSERT INTO `pizza` VALUES (1,'reine',9),(2,'oc_speciale',13),(3,'margharita',11);
/*!40000 ALTER TABLE `pizza` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `preparateur`
--

DROP TABLE IF EXISTS `preparateur`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preparateur` (
  `id_client` int(11) NOT NULL,
  PRIMARY KEY (`id_client`),
  CONSTRAINT `employe_preparateur_fk` FOREIGN KEY (`id_client`) REFERENCES `employe` (`id_client`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `preparateur`
--

LOCK TABLES `preparateur` WRITE;
/*!40000 ALTER TABLE `preparateur` DISABLE KEYS */;
INSERT INTO `preparateur` VALUES (2),(4);
/*!40000 ALTER TABLE `preparateur` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `promotion`
--

DROP TABLE IF EXISTS `promotion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `promotion` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(40) NOT NULL,
  `date_debut` date NOT NULL,
  `pourcentage` int(11) NOT NULL,
  `date_fin` date NOT NULL,
  `id_rest` int(11) NOT NULL,
  `id_pizza` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `pizza_promotion_fk` (`id_pizza`),
  KEY `restaurant_promotion_fk` (`id_rest`),
  CONSTRAINT `pizza_promotion_fk` FOREIGN KEY (`id_pizza`) REFERENCES `pizza` (`id_pizza`) ON UPDATE CASCADE,
  CONSTRAINT `restaurant_promotion_fk` FOREIGN KEY (`id_rest`) REFERENCES `restaurant` (`id_rest`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `promotion`
--

LOCK TABLES `promotion` WRITE;
/*!40000 ALTER TABLE `promotion` DISABLE KEYS */;
INSERT INTO `promotion` VALUES (1,'hiver2018','2017-12-01',5,'2018-02-01',1,2);
/*!40000 ALTER TABLE `promotion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recette`
--

DROP TABLE IF EXISTS `recette`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `recette` (
  `id_pizza` int(11) NOT NULL,
  `id_aliment` int(11) NOT NULL,
  `version` int(11) NOT NULL,
  `portion` int(11) NOT NULL,
  PRIMARY KEY (`id_pizza`,`id_aliment`,`version`),
  KEY `aliment_recette_fk` (`id_aliment`),
  CONSTRAINT `aliment_recette_fk` FOREIGN KEY (`id_aliment`) REFERENCES `aliment` (`id_aliment`) ON UPDATE CASCADE,
  CONSTRAINT `pizza_recette_fk` FOREIGN KEY (`id_pizza`) REFERENCES `pizza` (`id_pizza`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recette`
--

LOCK TABLES `recette` WRITE;
/*!40000 ALTER TABLE `recette` DISABLE KEYS */;
INSERT INTO `recette` VALUES (1,1,1,1),(1,2,1,1),(1,3,1,1),(1,4,1,1),(2,1,1,1),(2,2,1,1),(2,3,1,2),(2,4,1,0),(2,5,1,2),(3,1,1,1),(3,2,1,1),(3,3,1,2),(3,4,1,0),(3,5,1,0);
/*!40000 ALTER TABLE `recette` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `restaurant`
--

DROP TABLE IF EXISTS `restaurant`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `restaurant` (
  `id_rest` int(11) NOT NULL AUTO_INCREMENT,
  `adresse` varchar(40) NOT NULL,
  `nom` varchar(40) NOT NULL,
  `numTel` char(10) NOT NULL,
  PRIMARY KEY (`id_rest`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `restaurant`
--

LOCK TABLES `restaurant` WRITE;
/*!40000 ALTER TABLE `restaurant` DISABLE KEYS */;
INSERT INTO `restaurant` VALUES (1,'3 rue de la Paix','Paris Centre01','0101055304'),(2,'15 avenue de la Republique','Paris Est01','0198229002');
/*!40000 ALTER TABLE `restaurant` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stock`
--

DROP TABLE IF EXISTS `stock`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `stock` (
  `id_rest` int(11) NOT NULL,
  `id_aliment` int(11) NOT NULL,
  `statut` varchar(40) NOT NULL,
  `quantite_restante` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_rest`,`id_aliment`),
  KEY `aliment_stock_fk` (`id_aliment`),
  CONSTRAINT `aliment_stock_fk` FOREIGN KEY (`id_aliment`) REFERENCES `aliment` (`id_aliment`) ON UPDATE CASCADE,
  CONSTRAINT `restaurant_stock_fk` FOREIGN KEY (`id_rest`) REFERENCES `restaurant` (`id_rest`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stock`
--

LOCK TABLES `stock` WRITE;
/*!40000 ALTER TABLE `stock` DISABLE KEYS */;
INSERT INTO `stock` VALUES (1,1,'ok',5),(1,2,'ok',3),(1,3,'ok',4),(1,4,'ok',3),(1,5,'ok',2),(2,1,'ok',2),(2,2,'ko',0),(2,3,'ok',3),(2,4,'ok',3),(2,5,'ko',0);
/*!40000 ALTER TABLE `stock` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-01-21 21:13:25
